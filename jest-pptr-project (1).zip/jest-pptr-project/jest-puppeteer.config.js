module.exports = {
	launch: {
		headless: true,
	},
	browserContext: 'default',
}
