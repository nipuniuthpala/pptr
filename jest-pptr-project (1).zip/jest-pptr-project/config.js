export const username = 'username'
export const password = 'password'
export const timeout = 15000
