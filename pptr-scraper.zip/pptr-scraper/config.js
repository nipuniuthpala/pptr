module.exports = {
  url: 'http://books.toscrape.com/catalogue/tipping-the-velvet_999/index.html',
}
